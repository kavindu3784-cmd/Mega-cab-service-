package model;

public class Cab {
    private int bookingId;
    private String bookingTime;
    private int cabId;
    private String dropoffLocation;
    private String pickupLocation;
    private int userId;

    // Default Constructor
    public Cab() {}

    // Parameterized Constructor
    public Cab(int bookingId, String bookingTime, int cabId, String dropoffLocation, String pickupLocation, int userId) {
        this.bookingId = bookingId;
        this.bookingTime = bookingTime;
        this.cabId = cabId;
        this.dropoffLocation = dropoffLocation;
        this.pickupLocation = pickupLocation;
        this.userId = userId;
    }

    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public int getCabId() {
        return cabId;
    }

    public void setCabId(int cabId) {
        this.cabId = cabId;
    }

    public String getDropoffLocation() {
        return dropoffLocation;
    }

    public void setDropoffLocation(String dropoffLocation) {
        this.dropoffLocation = dropoffLocation;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
